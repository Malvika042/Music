import "./hero.scss"
import {motion} from "framer-motion";

const textVariants = {
    initial: {
        x: -500,
        opacity: 0,

    },
    animate: {
        x: 0,
        opacity: 1,
        transition: {
            duration: 1,
            staggerChildren: 0.1,
        },
    },

    scrollButton:{
        opacity: 0,
        y: 10,
        transition:{
            duration: 2,
            repeat: Infinity
        }
    }, 
};
const sliderVariants = {
    initial: {
        x: 0,
        

    },
    animate: {
        x: "-220%",
        
        transition: {
            repeat: Infinity,
            repeatType: "mirror",
            duration: 20,
        },
    },

    
};
const Hero = () => {
  return (
    <div className="hero">
        <div className="wrapper">

        
        <motion.div className="textContainer" variants = {textVariants} initial = "initial" animate= "animate">
            <motion.h2 variants = {textVariants}>Adheer Dixit</motion.h2>
            <motion.h1 variants = {textVariants}>Shammein meri <a href="https://youtube.com/playlist?list=OLAK5uy_lqVf135kS-fxdNdVVu1d2fnGAnKLiEhcU&si=txM4r_kIc1RqIe9K" target="_blank">
            <h5>Listen Now!</h5></a> </motion.h1>
            <motion.div variants = {textVariants} className="buttons">
                <motion.button variants = {textVariants}>See the Latest Track</motion.button>
                <motion.button variants = {textVariants}>Contact Me</motion.button>
            </motion.div>
            <motion.img variants = {textVariants} animate="scrollButton"src="/scroll.png" alt="" />
        </motion.div>
        </div>
        <motion.div className="slidingTextContainer" variants={sliderVariants} initial ="initial" animate="animate">
            Singer  lyricist 
        </motion.div>
      <div className="imageContainer">
        <img src="/Adheer (1).png" alt="" />
      </div>
    </div>
  );
};

export default Hero;
