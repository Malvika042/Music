// src/components/VideoPage.jsx
import {motion} from "framer-motion";
import React from 'react';
import './VideoPage.scss';

const videos = [
  {
    videoId: 'YqaaEbhF1QM',
    title: 'Shaamein Meri(Official Music Video)',
    views: '123,456',
  },
  {
    videoId: 'qkLdxoH2vOg',
    title: 'Teaser',
    views: '78,910',
  },
  {
    videoId: '5WbWFSPeAO8',
    title: 'Behind the Scenes-Vlog',
    views: '45,678',
  },
];

const VideoCard = ({ videoId, title, views }) => (
  <motion.div className="video-card">
    <iframe
      src={`https://www.youtube.com/embed/${videoId}`}
      title={title}
      frameBorder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      allowFullScreen
    ></iframe>
    <motion.h3>{title}</motion.h3>
    <motion.p>{views} views</motion.p>
  </motion.div>
);

const VideoPage = () => (
  <motion.div className="video-page"
  initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    transition={{ duration: 1 }}
    >
    <motion.h1>Music Videos</motion.h1>
    <motion.div className="video-gallery">
      {videos.map((video) => (
        <VideoCard key={video.videoId} {...video} />
      ))}
    </motion.div>
  </motion.div>
);

export default VideoPage;
