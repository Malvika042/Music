// src/components/MusicPage.jsx

import React from 'react';
import './MusicPage.scss';

const musicLinks = [
  {
    platform: 'Spotify',
    url: 'https://open.spotify.com/artist/1MgRoeMYjif5QKEsowJ4mJ',
    logo: '/spotify.png', // Update the path to your logo
  },
  {
    platform: 'Apple Music',
    url: 'https://music.apple.com/se/artist/adheer-dixit/1735397778?l=en-GB',
    logo: '/apple.png', // Update the path to your logo
  },
  {
    platform: 'Instagram',
    url: 'https://www.instagram.com/adheeeera',
    logo: '/instagram.png', // Update the path to your logo
  },
  {
    platform: 'YouTube',
    url: 'https://www.youtube.com/watch?v=F5xq94Dk0XI&list=OLAK5uy_lqVf135kS-fxdNdVVu1d2fnGAnKLiEhcU',
    logo: '/youtube.png', // Update the path to your logo
  },
];

const behindTheScenesImages = [
  '/Adheer.png',
  '/path/to/image2.jpg',
  '/path/to/image3.jpg',
  // Add more image paths here
];
const youtubeVideos = [
    {
      url: 'https://www.youtube.com/embed/F5xq94Dk0XI?autoplay=1',
      text: 'Check out our latest music video!',
    },
    {
      url: 'https://www.youtube.com/embed/YqaaEbhF1QM?autoplay=1',
      text: 'Watch our special performance!',
    },
  ];

const MusicPage = () => (
  <div className="music-page">
    <h1>Listen to the Music</h1>
    <ul className="music-links">
      {musicLinks.map((link) => (
        <li key={link.platform}>
          <a href={link.url} target="_blank" rel="noopener noreferrer">
            <img src={link.logo} alt={`${link.platform} logo`} />
            {link.platform}
          </a>
        </li>
      ))}
    </ul>
    <div className="youtube-videos">
      {youtubeVideos.map((video, index) => (
        <div key={index} className="youtube-video">
          <iframe
            width="560"
            height="315"
            src={video.url}
            title={`YouTube video ${index + 1}`}
            frameBorder="0"
            allow="autoplay; encrypted-media"
            allowFullScreen
          ></iframe>
          <p>{video.text}</p>
        </div>
      ))}
    </div>
   
  </div>
);

export default MusicPage;
