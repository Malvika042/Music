import "./app.scss"
import Contact from "./components/contact/Contact";
import Cursor from "./components/Cursor/Cursor";


import Hero from "./components/hero/Hero";
import MusicPage from "./components/Music/Musicpage";
import Navbar from "./components/navbar/Navbar";
import Parallax from "./components/parallax/parallax";
import VideoPage from "./components/Videos/Videopage";




const App = () => {
  return( 
  <div>
     <Cursor/>
    <section id="Home">
      <Navbar/>
      <Hero/>
    </section>
    <section id="Videos">
      <Parallax type="videos"/>
      </section> 
    <section>
      <VideoPage/>
      </section>
    <section id="Music Albums">
      <Parallax type="portfolio"/>
      </section>
     <section><MusicPage/>
    </section>
    <section id="Contact">
      <Contact/>
    </section>

  </div>
  );
};

export default App;
